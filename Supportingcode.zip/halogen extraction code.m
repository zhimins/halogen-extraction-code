clc
clear
warning off
foldername=uigetdir;
cd(foldername);
addpath(genpath(pwd));
list=dir([foldername,'\data\dataUMF\','*.csv']);%'*.csv'
list_AMF=dir([foldername,'\data\dataAMF\','*.CSV']);%'*.csv'
q=input('input the specific value of intensity that M/M+2, supposing that the intensity of M+2 is 1:')%%for cl :100/31.96; for Br :0.9786
p=1;
deltam=input('The difference in the mass of the isotope:') %% Cl is 1.997(Cl37-Cl35); Br is 1.998
percentage_error=input('the allowable error threshold for the specific value of intensity, the format is a decimal:') %% percentage error: 30
[Cl1_0,Cl1_1,Cl2_0,ppm_allow1,ppm_allow2] = ppm_range(list,list_AMF,q,percentage_error,deltam,foldername);
[list_MS]=MS_A(foldername,Cl1_0,Cl1_1,Cl2_0,ppm_allow1,ppm_allow2,percentage_error,deltam);
[list_UMF]=UMF_unsureCl(list_MS,foldername);


% q1=1/Cl1_0;
% q2=1/Cl1_1;
% q3=1/Cl2_0;
% h=waitbar(0,'MS_direct is calculating')
% for i=1:length(list_MS)
%     raw_result={};
%     splitname = strtok(list_MS(i,1).name,'.');
%     [~, Sheet, ~]=xlsfinfo([foldername,'\data\dataMS\',splitname,'*.csv']);
%     for l=1:length(Sheet)   
%     [~,~,raw_MS]=xlsread([foldername,'\data\dataMS\',list_MS(i,1).name],Sheet{l});
%     if(length(raw_MS{1,1})>length(raw_MS{1,2}))
%         raw_MS(:,[1,2])=raw_MS(:,[2,1]);
%     end
%     raw_result(1,[1,2])=raw_MS(1,[1,2]);
%     raw_result(1,[3,4])=raw_MS(1,[1,2]);
%     raw_result{1,5}='m:ppm_error';
%     raw_result{1,6}='intensity: M+2/M';
%     conter=1;
%     switch deltam
%         case 1.998
%         for j=2:size(raw_MS,1)-1
%             for k=j+1:size(raw_MS,1)
%                 if(raw_MS{k,1}>78&&ppm_allow2<(raw_MS{k,1}-raw_MS{j,1}-deltam)/raw_MS{j,1}*1000000&&(raw_MS{k,1}-raw_MS{j,1}-deltam)/raw_MS{j,1}*1000000<ppm_allow1)%&&((q1*(1-percentage_error)<raw_MS{j,2}/raw_MS{k,2}&&raw_MS{j,2}/raw_MS{k,2}<q1*(1+percentage_error))||(q2*(1-percentage_error)<raw_MS{j,2}/raw_MS{k,2}&&raw_MS{j,2}/raw_MS{k,2}<q2*(1+percentage_error))||(q3*(1-percentage_error)<raw_MS{j,2}/raw_MS{k,2}&&raw_MS{j,2}/raw_MS{k,2}<q3*(1+percentage_error))))
%                     if(abs((raw_MS{j,2}/raw_MS{k,2}-q1)/q1)<percentage_error)%(q1*(1-percentage_error)<raw_MS{j,2}/raw_MS{k,2}&&raw_MS{j,2}/raw_MS{k,2}<q1*(1+percentage_error))
%                         conter=conter+1;
%                         raw_result(conter,[1,2])=raw_MS(j,[1,2]);
%                         raw_result(conter,[3,4])=raw_MS(k,[1,2]);
%                         raw_result{conter,5}=(raw_MS{k,1}-raw_MS{j,1}-deltam)/raw_MS{j,1}*1000000;
%                         raw_result{conter,6}=(raw_MS{j,2}/raw_MS{k,2}-q1)/q1;
%                         break
%                     elseif(abs(raw_MS{j,2}/raw_MS{k,2}-q2)/q2<percentage_error)%(q2*(1-percentage_error)<raw_MS{j,2}/raw_MS{k,2}&&raw_MS{j,2}/raw_MS{k,2}<q2*(1+percentage_error))
%                         conter=conter+1;
%                         raw_result(conter,[1,2])=raw_MS(j,[1,2]);
%                         raw_result(conter,[3,4])=raw_MS(k,[1,2]);
%                         raw_result{conter,5}=(raw_MS{k,1}-raw_MS{j,1}-deltam)/raw_MS{j,1}*1000000;
%                         raw_result{conter,6}=(raw_MS{j,2}/raw_MS{k,2}-q2)/q2;
%                         break
%                     elseif(abs(raw_MS{j,2}/raw_MS{k,2}-q3)/q3<percentage_error)%(q3*(1-percentage_error)<raw_MS{j,2}/raw_MS{k,2}&&raw_MS{j,2}/raw_MS{k,2}<q3*(1+percentage_error))
%                         conter=conter+1;
%                         raw_result(conter,[1,2])=raw_MS(j,[1,2]);
%                         raw_result(conter,[3,4])=raw_MS(k,[1,2]);
%                         raw_result{conter,5}=(raw_MS{k,1}-raw_MS{j,1}-deltam)/raw_MS{j,1}*1000000;
%                         raw_result{conter,6}=(raw_MS{j,2}/raw_MS{k,2}-q3)/q3;
%                         break
%                     end
%                 end
%             end
%         end
%         case 1.997
%         for j=2:size(raw_MS,1)-1
%             for k=j+1:size(raw_MS,1)
%                 if(raw_MS{k,1}>36&&ppm_allow2<(raw_MS{k,1}-raw_MS{j,1}-deltam)/raw_MS{j,1}*1000000&&(raw_MS{k,1}-raw_MS{j,1}-deltam)/raw_MS{j,1}*1000000<ppm_allow1)%&&((q1*(1-percentage_error)<raw_MS{j,2}/raw_MS{k,2}&&raw_MS{j,2}/raw_MS{k,2}<q1*(1+percentage_error))||(q2*(1-percentage_error)<raw_MS{j,2}/raw_MS{k,2}&&raw_MS{j,2}/raw_MS{k,2}<q2*(1+percentage_error))||(q3*(1-percentage_error)<raw_MS{j,2}/raw_MS{k,2}&&raw_MS{j,2}/raw_MS{k,2}<q3*(1+percentage_error))))
%                     if(abs(raw_MS{j,2}/raw_MS{k,2}-q1)/q1<percentage_error)%(q1*(1-percentage_error)<raw_MS{j,2}/raw_MS{k,2}&&raw_MS{j,2}/raw_MS{k,2}<q1*(1+percentage_error))
%                         conter=conter+1;
%                         raw_result(conter,[1,2])=raw_MS(j,[1,2]);
%                         raw_result(conter,[3,4])=raw_MS(k,[1,2]);
%                         raw_result{conter,5}=(raw_MS{k,1}-raw_MS{j,1}-deltam)/raw_MS{j,1}*1000000;
%                         raw_result{conter,6}=(raw_MS{j,2}/raw_MS{k,2}-q1)/q1;
%                         break
%                     elseif(abs(raw_MS{j,2}/raw_MS{k,2}-q2)/q2<percentage_error)%(q2*(1-percentage_error)<raw_MS{j,2}/raw_MS{k,2}&&raw_MS{j,2}/raw_MS{k,2}<q2*(1+percentage_error))
%                         conter=conter+1;
%                         raw_result(conter,[1,2])=raw_MS(j,[1,2]);
%                         raw_result(conter,[3,4])=raw_MS(k,[1,2]);
%                         raw_result{conter,5}=(raw_MS{k,1}-raw_MS{j,1}-deltam)/raw_MS{j,1}*1000000;
%                         raw_result{conter,6}=(raw_MS{j,2}/raw_MS{k,2}-q2)/q2;
%                         break
%                     elseif(abs(raw_MS{j,2}/raw_MS{k,2}-q3)/q3<percentage_error)%(q3*(1-percentage_error)<raw_MS{j,2}/raw_MS{k,2}&&raw_MS{j,2}/raw_MS{k,2}<q3*(1+percentage_error))
%                         conter=conter+1;
%                         raw_result(conter,[1,2])=raw_MS(j,[1,2]);
%                         raw_result(conter,[3,4])=raw_MS(k,[1,2]);
%                         raw_result{conter,5}=(raw_MS{k,1}-raw_MS{j,1}-deltam)/raw_MS{j,1}*1000000;
%                         raw_result{conter,6}=(raw_MS{j,2}/raw_MS{k,2}-q3)/q3;
%                         break
%                     end
%                 end
%             end
%         end
%     end
%     xlswrite([foldername,'\output\MS_A\',[splitname,'_directMS']],raw_result,Sheet{l});
%     end
%     waitbar(i/length(list_MS))
% end
% close(h)